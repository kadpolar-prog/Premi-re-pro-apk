package com.pablo.premierepocket

data class PresetParameter(
    val name: String,
    val value: String?,
    val units: String?,
    val timeVarying: Boolean,
    val startKeyframe: String?,
    val keyframesRaw: String?
)

data class PresetEffect(
    val displayName: String,
    val matchName: String,
    val description: String?,
    val parameters: List<PresetParameter>,
    val support: PresetSupport
)

enum class PresetSupport { NATIVE, APPROXIMATE, IMPORT_ONLY }

data class Preset(
    val name: String,
    val sourceType: String,
    val effects: List<PresetEffect>,
    val rawPreview: String,
    val warnings: List<String> = emptyList()
) {
    val detectedEffects: List<String> get() = effects.map { it.displayName.ifBlank { e -> e.matchName } }
}
