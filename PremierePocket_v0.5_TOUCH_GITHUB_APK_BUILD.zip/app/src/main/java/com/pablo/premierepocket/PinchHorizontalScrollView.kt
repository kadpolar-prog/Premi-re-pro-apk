package com.pablo.premierepocket

import android.content.Context
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.HorizontalScrollView

/** HorizontalScrollView that observes pinch gestures before child views consume them. */
class PinchHorizontalScrollView(context: Context) : HorizontalScrollView(context) {
    var onPinch: ((scaleFactor: Float, focusX: Float) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean = true
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                onPinch?.invoke(detector.scaleFactor, detector.focusX)
                return true
            }
        })

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        if (scaleDetector.isInProgress) parent?.requestDisallowInterceptTouchEvent(true)
        return super.dispatchTouchEvent(ev)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (scaleDetector.isInProgress) return true
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (scaleDetector.isInProgress) return true
        return super.onTouchEvent(ev)
    }
}
