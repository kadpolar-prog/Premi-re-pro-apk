package com.pablo.premierepocket

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object ProjectStore {
    fun save(context: Context, project: EditorProject): File {
        val root = JSONObject().put("name", project.name).put("selectedClipId", project.selectedClipId)
        val clips = JSONArray()
        project.clips.forEach { c ->
            clips.put(JSONObject()
                .put("id", c.id).put("uri", c.uri.toString()).put("name", c.name)
                .put("sourceInMs", c.sourceInMs).put("sourceOutMs", c.sourceOutMs)
                .put("sourceDurationMs", c.sourceDurationMs)
                .put("timelineStartMs", c.timelineStartMs).put("track", c.track)
                .put("opacity", c.opacity.toDouble()).put("scale", c.scale.toDouble())
                .put("rotation", c.rotation.toDouble()).put("volume", c.volume.toDouble()))
        }
        val texts = JSONArray()
        project.textLayers.forEach { t -> texts.put(JSONObject().put("id", t.id).put("text", t.text).put("startMs", t.startMs).put("durationMs", t.durationMs).put("track", t.track)) }
        root.put("clips", clips).put("texts", texts)
        val file = File(context.filesDir, "premiere_pocket_project.json")
        file.writeText(root.toString(2))
        return file
    }
}
