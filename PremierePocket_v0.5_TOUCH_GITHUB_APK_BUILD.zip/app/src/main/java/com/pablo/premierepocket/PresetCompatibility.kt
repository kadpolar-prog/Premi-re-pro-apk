package com.pablo.premierepocket

object PresetCompatibility {
    fun classify(displayName: String, matchName: String): PresetSupport {
        val s = "$displayName $matchName".lowercase()
        return when {
            listOf("opacity", "opacité", "motion", "mouvement", "transform").any { it in s } -> PresetSupport.NATIVE
            listOf("volume", "gain", "bass", "treble", "highpass", "lowpass", "equalizer", "eq").any { it in s } -> PresetSupport.APPROXIMATE
            else -> PresetSupport.IMPORT_ONLY
        }
    }
}
