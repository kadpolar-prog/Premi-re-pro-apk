package com.pablo.premierepocket

import android.net.Uri

data class ClipModel(
    val id: Long = System.nanoTime(),
    val uri: Uri,
    val name: String,
    var sourceInMs: Long = 0L,
    var sourceOutMs: Long = 0L,
    var sourceDurationMs: Long = 0L,
    var timelineStartMs: Long = 0L,
    var track: Int = 0,
    var opacity: Float = 1f,
    var scale: Float = 1f,
    var rotation: Float = 0f,
    var volume: Float = 1f,
    val appliedPresets: MutableList<Preset> = mutableListOf()
) {
    val durationMs: Long get() = (sourceOutMs - sourceInMs).coerceAtLeast(0L)
}

data class TextLayerModel(
    val id: Long = System.nanoTime(),
    var text: String,
    var startMs: Long,
    var durationMs: Long = 3000,
    var track: Int = 2
)

class EditorProject(val name: String = "Nouveau projet") {
    val clips = mutableListOf<ClipModel>()
    val textLayers = mutableListOf<TextLayerModel>()
    var selectedClipId: Long? = null
    fun selectedClip(): ClipModel? = clips.firstOrNull { it.id == selectedClipId }
    fun durationMs(): Long = maxOf(
        clips.maxOfOrNull { it.timelineStartMs + it.durationMs } ?: 0L,
        textLayers.maxOfOrNull { it.startMs + it.durationMs } ?: 0L
    )
}
