package com.pablo.premierepocket

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/**
 * Touch-first timeline clip:
 * - tap centre: select
 * - drag centre: move in time / between tracks
 * - drag left or right edge: trim
 * A touch slop is required before editing starts, so normal taps do not move clips.
 */
class TimelineClipView(
    context: Context,
    title: String,
    selected: Boolean,
    private val onTouchSelect: () -> Unit,
    private val onTap: () -> Unit,
    private val onMoveCommit: (dxPx: Float, dyPx: Float) -> Unit,
    private val onTrimLeftCommit: (dxPx: Float) -> Unit,
    private val onTrimRightCommit: (dxPx: Float) -> Unit,
    private val onDragMove: (rawX: Float) -> Unit = {},
    private val scrollXProvider: () -> Int = { 0 }
) : FrameLayout(context) {

    private enum class Mode { MOVE, TRIM_LEFT, TRIM_RIGHT }

    private val density = resources.displayMetrics.density
    private val handleWidth = 18f * density
    private val minVisualWidth = 44 * density
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var originalWidth = 0
    private var mode = Mode.MOVE
    private var editing = false
    private var effectiveDx = 0f
    private var startScrollX = 0

    init {
        isClickable = true
        isFocusable = true
        clipChildren = false
        clipToPadding = false

        val fill = if (selected) Color.rgb(70, 95, 170) else Color.rgb(54, 100, 154)
        background = roundedStroke(fill, if (selected) Color.rgb(144, 180, 255) else Color.rgb(94, 142, 201), 2f)

        addView(TextView(context).apply {
            text = title
            setTextColor(Color.rgb(238, 243, 255))
            textSize = 9f
            gravity = Gravity.CENTER_VERTICAL
            setPadding((22 * density).toInt(), 0, (22 * density).toInt(), 0)
            maxLines = 1
        }, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        addView(edgeHandle(true), LayoutParams(handleWidth.toInt(), LayoutParams.MATCH_PARENT, Gravity.START))
        addView(edgeHandle(false), LayoutParams(handleWidth.toInt(), LayoutParams.MATCH_PARENT, Gravity.END))
    }

    override fun performClick(): Boolean {
        super.performClick()
        onTap()
        return true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                originalWidth = width
                editing = false
                effectiveDx = 0f
                startScrollX = scrollXProvider()
                mode = when {
                    event.x <= handleWidth -> Mode.TRIM_LEFT
                    event.x >= width - handleWidth -> Mode.TRIM_RIGHT
                    else -> Mode.MOVE
                }
                onTouchSelect()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!editing && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                    editing = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                if (!editing) return true
                onDragMove(event.rawX)

                when (mode) {
                    Mode.MOVE -> {
                        translationX = dx
                        translationY = dy
                        effectiveDx = dx
                    }
                    Mode.TRIM_LEFT -> {
                        val maxDx = originalWidth - minVisualWidth
                        effectiveDx = dx.coerceAtMost(maxDx)
                        layoutParams = layoutParams.apply {
                            width = max(minVisualWidth.toInt(), (originalWidth - effectiveDx).toInt())
                        }
                        translationX = effectiveDx
                    }
                    Mode.TRIM_RIGHT -> {
                        val minDx = -(originalWidth - minVisualWidth)
                        effectiveDx = dx.coerceAtLeast(minDx)
                        layoutParams = layoutParams.apply {
                            width = max(minVisualWidth.toInt(), (originalWidth + effectiveDx).toInt())
                        }
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                val wasEditing = editing
                val dx = effectiveDx + (scrollXProvider() - startScrollX)
                val dy = event.rawY - downY

                translationX = 0f
                translationY = 0f
                if (originalWidth > 0) layoutParams = layoutParams.apply { width = originalWidth }

                if (event.actionMasked == MotionEvent.ACTION_UP && wasEditing) {
                    when (mode) {
                        Mode.MOVE -> onMoveCommit(dx, dy)
                        Mode.TRIM_LEFT -> onTrimLeftCommit(dx)
                        Mode.TRIM_RIGHT -> onTrimRightCommit(dx)
                    }
                    performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                    performClick()
                }
                editing = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun edgeHandle(left: Boolean) = View(context).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(if (selected) Color.rgb(129, 164, 239) else Color.rgb(84, 129, 184))
            cornerRadius = 2f * density
        }
        contentDescription = if (left) "Poignée de trim gauche" else "Poignée de trim droite"
    }

    private fun roundedStroke(fill: Int, stroke: Int, radiusDp: Float) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        setStroke((1 * density).toInt().coerceAtLeast(1), stroke)
        cornerRadius = radiusDp * density
    }
}
