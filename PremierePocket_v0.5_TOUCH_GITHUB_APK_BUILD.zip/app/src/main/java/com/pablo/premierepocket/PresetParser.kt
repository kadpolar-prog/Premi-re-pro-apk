package com.pablo.premierepocket

import android.content.ContentResolver
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

object PresetParser {
    fun parse(resolver: ContentResolver, uri: Uri): Preset {
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Impossible de lire le preset")
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Preset"
        return parseBytes(bytes, name)
    }

    fun parseBytes(bytes: ByteArray, fileName: String): Preset {
        val text = decodeBestEffort(bytes)
        val trimmed = text.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (trimmed.startsWith("{")) return parseJson(trimmed, fileName)
        if (trimmed.startsWith("<")) {
            try { return parsePremiereXml(bytes, text, fileName) } catch (_: Exception) { /* fallback */ }
        }
        return heuristicParse(text, fileName, listOf("Structure XML Adobe non reconnue : import conservé en mode compatible."))
    }

    private fun parsePremiereXml(bytes: ByteArray, text: String, fileName: String): Preset {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = false
            isXIncludeAware = false
            try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) {}
            try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) {}
            try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) {}
        }
        val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
        doc.documentElement.normalize()

        val objectMap = mutableMapOf<String, Element>()
        val all = doc.getElementsByTagName("*")
        for (i in 0 until all.length) {
            val e = all.item(i) as? Element ?: continue
            val id = e.getAttribute("ObjectID")
            if (id.isNotBlank()) objectMap[id] = e
        }

        val effects = mutableListOf<PresetEffect>()
        val presets = doc.getElementsByTagName("FilterPreset")
        for (i in 0 until presets.length) {
            val fp = presets.item(i) as? Element ?: continue
            if (!fp.hasAttribute("ObjectID")) continue // ignore the list container
            val matchName = childText(fp, "FilterMatchName").orEmpty()
            val description = childText(fp, "Description")
            val componentRef = firstDescendantWithAttribute(fp, "Component", "ObjectRef")?.getAttribute("ObjectRef")
            val component = componentRef?.let { objectMap[it] }
            val displayName = component?.let { descendantText(it, "DisplayName") }
                ?.takeIf { it.isNotBlank() } ?: matchName.ifBlank { "Effet Adobe" }

            val params = mutableListOf<PresetParameter>()
            if (component != null) {
                val paramNodes = component.getElementsByTagName("Param")
                for (p in 0 until paramNodes.length) {
                    val pe = paramNodes.item(p) as? Element ?: continue
                    val ref = pe.getAttribute("ObjectRef")
                    val param = objectMap[ref] ?: continue
                    params += PresetParameter(
                        name = descendantText(param, "Name").orEmpty().ifBlank { "Paramètre ${p + 1}" },
                        value = descendantText(param, "CurrentValue") ?: startKeyframeValue(descendantText(param, "StartKeyframe")),
                        units = descendantText(param, "UnitsString")?.takeIf { it.isNotBlank() },
                        timeVarying = descendantText(param, "IsTimeVarying")?.equals("true", true) == true,
                        startKeyframe = descendantText(param, "StartKeyframe"),
                        keyframesRaw = descendantText(param, "Keyframes")?.takeIf { it.isNotBlank() }
                    )
                }
            }
            effects += PresetEffect(displayName, matchName, description, params.distinctBy { it.name }, PresetCompatibility.classify(displayName, matchName))
        }

        if (effects.isEmpty()) return heuristicParse(text, fileName, listOf("Aucun FilterPreset Adobe résolu par ObjectRef."))
        return Preset(fileName, "Adobe Premiere .prfpset (XML)", effects.distinctBy { it.matchName + it.displayName }, text.take(3000))
    }

    private fun parseJson(text: String, fileName: String): Preset {
        val obj = JSONObject(text)
        val name = obj.optString("name", fileName)
        val arr = obj.optJSONArray("effects") ?: JSONArray()
        val effects = mutableListOf<PresetEffect>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i)
            if (e == null) {
                val label = arr.optString(i, "Effet ${i + 1}")
                effects += PresetEffect(label, label, null, emptyList(), PresetCompatibility.classify(label, label))
                continue
            }
            val display = e.optString("displayName", e.optString("name", "Effet ${i + 1}"))
            val match = e.optString("matchName", display)
            val parr = e.optJSONArray("parameters") ?: JSONArray()
            val params = mutableListOf<PresetParameter>()
            for (j in 0 until parr.length()) {
                val p = parr.optJSONObject(j) ?: continue
                params += PresetParameter(
                    p.optString("name", "Paramètre ${j + 1}"),
                    if (p.has("value")) p.opt("value")?.toString() else null,
                    p.optString("units").takeIf { it.isNotBlank() },
                    p.optBoolean("timeVarying", false),
                    p.optString("startKeyframe").takeIf { it.isNotBlank() },
                    p.optString("keyframesRaw").takeIf { it.isNotBlank() }
                )
            }
            effects += PresetEffect(display, match, e.optString("description").takeIf { it.isNotBlank() }, params, PresetCompatibility.classify(display, match))
        }
        return Preset(name, "Premiere Pocket JSON", effects, text.take(3000))
    }

    private fun heuristicParse(text: String, fileName: String, warnings: List<String>): Preset {
        val names = linkedSetOf<String>()
        listOf(
            Regex("<DisplayName>(.*?)</DisplayName>", RegexOption.IGNORE_CASE),
            Regex("<FilterMatchName>(.*?)</FilterMatchName>", RegexOption.IGNORE_CASE),
            Regex("<MatchName>(.*?)</MatchName>", RegexOption.IGNORE_CASE),
            Regex("AE\\.[A-Za-z0-9 _.-]+")
        ).forEach { p -> p.findAll(text).take(100).forEach { m ->
            val v = (m.groups.getOrNull(1)?.value ?: m.value).replace("&amp;", "&").trim()
            if (v.length in 2..120) names += v
        }}
        val effects = names.map { PresetEffect(it, it, null, emptyList(), PresetCompatibility.classify(it, it)) }
        return Preset(fileName, if (fileName.endsWith(".prfpset", true)) "Adobe Premiere .prfpset" else "Preset texte/binaire", effects, text.take(3000), warnings)
    }

    private fun decodeBestEffort(bytes: ByteArray): String {
        val utf8 = bytes.toString(Charsets.UTF_8)
        if (utf8.count { it == '\u0000' } < utf8.length / 8) return utf8
        return try { bytes.toString(Charsets.UTF_16LE) } catch (_: Exception) { utf8 }
    }

    private fun childText(parent: Element, tag: String): String? {
        val nodes = parent.childNodes
        for (i in 0 until nodes.length) {
            val e = nodes.item(i) as? Element ?: continue
            if (e.tagName.equals(tag, true)) return e.textContent?.trim()
        }
        return null
    }

    private fun descendantText(parent: Element, tag: String): String? {
        val nodes = parent.getElementsByTagName(tag)
        return if (nodes.length > 0) nodes.item(0).textContent?.trim() else null
    }

    private fun firstDescendantWithAttribute(parent: Element, tag: String, attr: String): Element? {
        val nodes = parent.getElementsByTagName(tag)
        for (i in 0 until nodes.length) {
            val e = nodes.item(i) as? Element ?: continue
            if (e.hasAttribute(attr)) return e
        }
        return null
    }

    private fun startKeyframeValue(start: String?): String? = start?.split(',')?.getOrNull(1)?.trim()
}
