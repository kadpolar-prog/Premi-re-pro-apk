package com.pablo.premierepocket

import android.content.ContentResolver
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

object TrimExporter {
    /**
     * Copie les pistes audio/vidéo entre inMs et outMs sans réencodage.
     * Très rapide et sans perte, mais la coupe commence au keyframe vidéo précédent.
     */
    fun export(
        resolver: ContentResolver,
        input: Uri,
        output: File,
        inMs: Long,
        outMs: Long
    ) {
        val pfd = resolver.openFileDescriptor(input, "r") ?: error("Source inaccessible")
        val extractor = MediaExtractor()
        extractor.setDataSource(pfd.fileDescriptor)

        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val trackMap = mutableMapOf<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(android.media.MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i)
                trackMap[i] = muxer.addTrack(format)
            }
        }
        muxer.start()
        extractor.seekTo(inMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

        val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        val firstPtsByTrack = mutableMapOf<Int, Long>()

        while (true) {
            val srcTrack = extractor.sampleTrackIndex
            if (srcTrack < 0) break
            val sampleTime = extractor.sampleTime
            if (sampleTime < 0 || sampleTime > outMs * 1000) break
            val dstTrack = trackMap[srcTrack]
            if (dstTrack == null) {
                extractor.advance(); continue
            }
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            val first = firstPtsByTrack.getOrPut(srcTrack) { sampleTime }
            info.set(0, size, (sampleTime - first).coerceAtLeast(0), extractor.sampleFlags)
            muxer.writeSampleData(dstTrack, buffer, info)
            extractor.advance()
        }

        muxer.stop()
        muxer.release()
        extractor.release()
        pfd.close()
    }
}
