package com.pablo.premierepocket

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

class MainActivity : Activity() {
    private lateinit var previewFrame: FrameLayout
    private lateinit var preview: VideoView
    private lateinit var status: TextView
    private lateinit var playButton: TextView
    private lateinit var timeline: LinearLayout
    private lateinit var timelineFrame: FrameLayout
    private lateinit var timelineScroll: PinchHorizontalScrollView
    private lateinit var timelineRulerView: View
    private lateinit var playheadView: View
    private lateinit var projectList: LinearLayout
    private lateinit var effectList: LinearLayout
    private lateinit var inText: TextView
    private lateinit var outText: TextView
    private lateinit var opacitySeek: SeekBar
    private lateinit var scaleSeek: SeekBar
    private lateinit var rotationSeek: SeekBar
    private lateinit var volumeSeek: SeekBar

    private var mediaPlayer: MediaPlayer? = null
    private val project = EditorProject()
    private var currentMedia: Uri? = null
    private var currentDurationMs = 0L
    private var inMs = 0L
    private var outMs = 0L
    private var loadedPreset: Preset? = null
    private var timelineZoom = 1f
    private var playheadTimeMs = 0L
    private var snappingEnabled = true
    private val textViews = mutableMapOf<Long, TextView>()

    private val bg = Color.rgb(18, 18, 20)
    private val panel = Color.rgb(34, 34, 38)
    private val panel2 = Color.rgb(46, 46, 52)
    private val panel3 = Color.rgb(27, 27, 31)
    private val divider = Color.rgb(64, 64, 70)
    private val accent = Color.rgb(87, 105, 229)
    private val clipBlue = Color.rgb(54, 100, 154)
    private val audioGreen = Color.rgb(47, 111, 88)
    private val text = Color.rgb(226, 226, 230)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        setContentView(buildUi())
        refreshProjectPanel()
        drawTimeline()
        refreshEffectsPanel()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        root.addView(buildAppMenuBar(), LinearLayout.LayoutParams(-1, dp(30)))
        root.addView(buildWorkspaceBar(), LinearLayout.LayoutParams(-1, dp(38)))

        val upper = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(panel3)
        }
        upper.addView(buildProjectPanel(), LinearLayout.LayoutParams(dp(276), -1))
        upper.addView(separatorVertical(), LinearLayout.LayoutParams(dp(1), -1))
        upper.addView(buildCenterPanel(), LinearLayout.LayoutParams(0, -1, 1f))
        upper.addView(separatorVertical(), LinearLayout.LayoutParams(dp(1), -1))
        upper.addView(buildEffectsPanel(), LinearLayout.LayoutParams(dp(310), -1))

        val workspace = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        workspace.addView(upper, LinearLayout.LayoutParams(-1, 0, 0.56f))
        workspace.addView(thinDivider(), LinearLayout.LayoutParams(-1, dp(1)))
        workspace.addView(buildTimeline(), LinearLayout.LayoutParams(-1, 0, 0.44f))
        root.addView(workspace, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            setTextColor(Color.rgb(172, 172, 178)); textSize = 9f; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0); setBackgroundColor(Color.rgb(20,20,23))
            text = "Prêt   |   00:00:00:00   |   Séquence 01   |   1920 × 1080   |   25,00 i/s"
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(22)))
        return root
    }

    private fun buildAppMenuBar(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), 0, dp(7), 0); setBackgroundColor(Color.rgb(26,26,29))
            addView(TextView(this@MainActivity).apply {
                text = "Pr"; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD); background = rounded(Color.rgb(90,82,196), 3f)
            }, LinearLayout.LayoutParams(dp(25), dp(22)).apply { setMargins(0,0,dp(8),0) })
            listOf("Fichier", "Édition", "Clip", "Séquence", "Marqueurs", "Graphiques et titres", "Fenêtre", "Aide").forEach { name ->
                addView(menuText(name))
            }
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(smallIcon("⌕") { toast("Recherche") }, LinearLayout.LayoutParams(dp(30), dp(25)))
            addView(TextView(this@MainActivity).apply {
                text = "Premiere Pocket"; setTextColor(Color.rgb(196,196,202)); textSize = 9f; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8),0,dp(4),0)
            })
        }
    }

    private fun buildWorkspaceBar(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), 0, dp(7), 0); setBackgroundColor(Color.rgb(31,31,35))
            addView(primaryButton("Importer") { openMedia() })
            addView(button("Preset .prfpset") { openPreset() })
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(dp(15), 1))
            listOf("Importation", "Montage", "Couleur", "Effets", "Audio", "Légendes et graphiques").forEachIndexed { i, name ->
                addView(workspaceTab(name, i == 1))
            }
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
            addView(button("+ Texte") { addTextLayer() })
            addView(primaryButton("Exporter") { exportSelectedTrim() })
        }
    }

    private fun buildProjectPanel(): View {
        val shell = panelShell()
        shell.addView(panelTabs("Projet : Nouveau projet", "Média"))
        shell.addView(thinDivider(), LinearLayout.LayoutParams(-1, dp(1)))

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(5), dp(6), dp(4))
        }
        searchRow.addView(TextView(this).apply {
            text = "⌕  Rechercher"; setTextColor(Color.rgb(145,145,151)); textSize = 9f; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8),0,dp(8),0); background = strokeBox(Color.rgb(39,39,44), Color.rgb(72,72,79), 3f)
        }, LinearLayout.LayoutParams(0, dp(28), 1f))
        searchRow.addView(smallIcon("≡") { toast("Vue Liste") }, LinearLayout.LayoutParams(dp(32), dp(28)))
        searchRow.addView(smallIcon("▦") { toast("Vue Icônes") }, LinearLayout.LayoutParams(dp(32), dp(28)))
        shell.addView(searchRow, LinearLayout.LayoutParams(-1, dp(39)))

        val binRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), 0, dp(7), 0); setBackgroundColor(Color.rgb(29,29,33))
            addView(labelSmall("Nom"), LinearLayout.LayoutParams(0, -1, 1f))
            addView(labelSmall("Durée"), LinearLayout.LayoutParams(dp(58), -1))
        }
        shell.addView(binRow, LinearLayout.LayoutParams(-1, dp(25)))

        val scroll = ScrollView(this)
        projectList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(5), dp(4), dp(5), dp(4)) }
        scroll.addView(projectList)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(5),0,dp(5),0); setBackgroundColor(Color.rgb(28,28,32))
            addView(smallIcon("□") { toast("Nouveau chutier") })
            addView(smallIcon("＋") { openMedia() })
            addView(smallIcon("◫") { toast("Nouvel élément") })
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0,1,1f))
            addView(smallIcon("⌫") { project.selectedClip()?.let { clip -> project.clips.remove(clip); project.selectedClipId = null; refreshProjectPanel(); refreshEffectsPanel(); drawTimeline() } })
        }
        shell.addView(footer, LinearLayout.LayoutParams(-1, dp(31)))
        return shell
    }

    private fun buildCenterPanel(): View {
        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(panel3) }
        center.addView(buildSourceMonitor(), LinearLayout.LayoutParams(0, -1, 0.48f))
        center.addView(separatorVertical(), LinearLayout.LayoutParams(dp(1), -1))
        center.addView(buildProgramMonitor(), LinearLayout.LayoutParams(0, -1, 0.52f))
        return center
    }

    private fun buildSourceMonitor(): View {
        val shell = panelShell()
        shell.addView(panelTabs("Source : (aucun élément)", "Contrôles d'effets"))
        val blank = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(8,8,9))
            addView(TextView(this@MainActivity).apply {
                text = "Double-clique un média dans le panneau Projet"; setTextColor(Color.rgb(92,92,98)); textSize = 10f; gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(-1,-1))
        }
        shell.addView(blank, LinearLayout.LayoutParams(-1, 0, 1f))
        shell.addView(buildMonitorFooter(isProgram = false), LinearLayout.LayoutParams(-1, dp(52)))
        return shell
    }

    private fun buildProgramMonitor(): View {
        val shell = panelShell()
        shell.addView(panelTabs("Programme : Séquence 01"))
        previewFrame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(7,7,8)) }
        preview = VideoView(this).apply {
            setOnPreparedListener { mp ->
                mediaPlayer = mp
                currentDurationMs = mp.duration.toLong().coerceAtLeast(0L)
                outMs = currentDurationMs
                refreshTrimLabels()
                status.text = "Programme   |   ${formatTimecode(currentDurationMs)}   |   Séquence 01   |   1920 × 1080   |   25,00 i/s"
                project.selectedClip()?.let { clip ->
                    clip.sourceDurationMs = currentDurationMs
                    if (clip.sourceOutMs <= 0) clip.sourceOutMs = currentDurationMs
                    applyClipPreviewProperties(clip)
                }
                drawTimeline()
            }
            setOnCompletionListener { if (::playButton.isInitialized) playButton.text = "▶" }
        }
        previewFrame.addView(preview, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        shell.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        shell.addView(buildMonitorFooter(isProgram = true), LinearLayout.LayoutParams(-1, dp(52)))
        return shell
    }

    private fun buildMonitorFooter(isProgram: Boolean): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(31,31,35))
            val timeRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7),0,dp(7),0)
                addView(TextView(this@MainActivity).apply {
                    text = "00:00:00:00"; setTextColor(Color.rgb(112,180,255)); textSize = 11f; setTypeface(typeface, Typeface.BOLD)
                })
                addView(Space(this@MainActivity), LinearLayout.LayoutParams(0,1,1f))
                addView(labelSmall(if (isProgram) "Ajuster" else "Composite Video"))
                addView(labelSmall("1/2"))
                addView(smallIcon("⚙") { toast("Réglages du moniteur") })
            }
            addView(timeRow, LinearLayout.LayoutParams(-1, dp(24)))

            val transport = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            addView(smallIcon("⏮") { seekRelative(-1000) })
            addView(smallIcon("◀") { seekRelative(-40) })
            if (isProgram) {
                playButton = smallIcon("▶") {
                    if (preview.isPlaying) { preview.pause(); playButton.text = "▶" }
                    else { preview.start(); playButton.text = "❚❚" }
                }
                addView(playButton)
            } else addView(smallIcon("▶") { if (currentMedia != null) preview.start() })
            addView(smallIcon("▶") { seekRelative(40) })
            addView(smallIcon("⏭") { seekRelative(1000) })
            if (isProgram) {
                addView(smallIcon("{") { inMs = preview.currentPosition.toLong(); project.selectedClip()?.sourceInMs = inMs; refreshTrimLabels(); drawTimeline() })
                addView(smallIcon("}") { outMs = preview.currentPosition.toLong(); project.selectedClip()?.sourceOutMs = outMs; refreshTrimLabels(); drawTimeline() })
                inText = labelSmall("IN 00:00.000"); outText = labelSmall("OUT 00:00.000")
            }
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0,1,1f))
            addView(smallIcon("＋") { toast("Éditeur de boutons") })
            addView(smallIcon("⋮") { toast("Menu du moniteur") })
            addView(transport, LinearLayout.LayoutParams(-1, dp(28)))
        }
    }

    private fun buildTimeline(): View {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.rgb(24,24,27)) }
        outer.addView(buildToolRail(), LinearLayout.LayoutParams(dp(38), -1))
        outer.addView(separatorVertical(), LinearLayout.LayoutParams(dp(1), -1))

        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(24,24,27)) }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4),0,dp(4),0); setBackgroundColor(Color.rgb(31,31,35))
            addView(panelTabs("Séquence 01"), LinearLayout.LayoutParams(0, -1, 1f))
            addView(labelSmall("25,00 i/s"))
            addView(smallIcon("≡") { toast("Menu Timeline") })
        }
        shell.addView(top, LinearLayout.LayoutParams(-1, dp(34)))

        val timelineControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6),0,dp(6),0); setBackgroundColor(Color.rgb(28,28,32))
            addView(smallIcon("↶") { toast("Annuler") })
            addView(smallIcon("↷") { toast("Rétablir") })
            addView(smallIcon("⌁") {
                snappingEnabled = !snappingEnabled
                toast(if (snappingEnabled) "Accrochage activé" else "Accrochage désactivé")
            })
            addView(smallIcon("🔗") { toast("Sélection liée") })
            addView(labelSmall("  Tactile : glisser • poignées = trim • pincer = zoom  "))
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0,1,1f))
            addView(TextView(this@MainActivity).apply {
                text = "100%"; tag = "zoomLabel"; setTextColor(Color.rgb(177,177,184)); textSize = 9f; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(45), -1))
            addView(TextView(this@MainActivity).apply { text = "00:00:00:00"; tag = "timelineTimecode"; setTextColor(Color.rgb(112,180,255)); textSize = 10f; setTypeface(typeface, Typeface.BOLD) })
        }
        shell.addView(timelineControls, LinearLayout.LayoutParams(-1, dp(30)))

        timelineScroll = PinchHorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_ALWAYS
        }

        timelineRulerView = object : View(this) {
            private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(113,113,120); strokeWidth = dp(1).toFloat(); textSize = dp(8).toFloat() }
            private val majorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(163,163,170); strokeWidth = dp(1).toFloat(); textSize = dp(8).toFloat() }
            private val playPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(93,174,255); strokeWidth = dp(2).toFloat() }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                canvas.drawColor(Color.rgb(21,21,24))
                val header = dp(108).toFloat()
                val ppm = timelinePixelsPerMs()
                val scroll = if (::timelineScroll.isInitialized) timelineScroll.scrollX.toFloat() else 0f
                val step = rulerStepMs()
                val startMs = (((scroll - header).coerceAtLeast(0f) / ppm).toLong() / step) * step
                val endMs = ((scroll + width + dp(250)) / ppm).toLong().coerceAtLeast(step)
                var t = startMs
                while (t <= endMs) {
                    val x = header + t * ppm - scroll
                    if (x >= header - dp(40) && x <= width + dp(40)) {
                        canvas.drawLine(x, height.toFloat(), x, dp(8).toFloat(), majorPaint)
                        canvas.drawText(formatTimecode(t), x + dp(3), dp(10).toFloat(), majorPaint)
                        val half = t + step / 2
                        val hx = header + half * ppm - scroll
                        canvas.drawLine(hx, height.toFloat(), hx, dp(14).toFloat(), tickPaint)
                    }
                    t += step
                }
                canvas.drawLine(header, 0f, header, height.toFloat(), tickPaint)
                val px = header + playheadTimeMs * ppm - scroll
                if (px >= header && px <= width) {
                    canvas.drawLine(px, 0f, px, height.toFloat(), playPaint)
                    val path = android.graphics.Path().apply {
                        moveTo(px - dp(5), 0f); lineTo(px + dp(5), 0f); lineTo(px, dp(7).toFloat()); close()
                    }
                    canvas.drawPath(path, playPaint)
                }
            }

            override fun onTouchEvent(event: MotionEvent): Boolean {
                if (event.x < dp(108)) return true
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                        parent?.requestDisallowInterceptTouchEvent(true)
                        val contentX = timelineScroll.scrollX + event.x - dp(108)
                        setPlayheadTimelineTime((contentX / timelinePixelsPerMs()).roundToLong(), seekPreview = true)
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        parent?.requestDisallowInterceptTouchEvent(false)
                        return true
                    }
                }
                return true
            }
        }.apply { setBackgroundColor(Color.rgb(21,21,24)) }
        shell.addView(timelineRulerView, LinearLayout.LayoutParams(-1, dp(24)))

        val verticalScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = true; clipToPadding = false }
        timelineFrame = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            setBackgroundColor(Color.rgb(23,23,26))
        }
        timeline = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(1), dp(4), dp(6))
            setBackgroundColor(Color.rgb(23,23,26))
            clipChildren = false
            clipToPadding = false
        }
        timelineFrame.addView(timeline, FrameLayout.LayoutParams(-2, -2))
        playheadView = View(this).apply { setBackgroundColor(Color.rgb(88,170,255)); isClickable = false }
        timelineFrame.addView(playheadView, FrameLayout.LayoutParams(dp(2), -1))
        verticalScroll.addView(timelineFrame, ScrollView.LayoutParams(-2, -2))
        timelineScroll.addView(verticalScroll, HorizontalScrollView.LayoutParams(-2, -1))
        shell.addView(timelineScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        timelineScroll.onPinch = { factor, focusX ->
            val oldPpm = timelinePixelsPerMs()
            val focusTime = ((timelineScroll.scrollX + focusX - dp(108)).coerceAtLeast(0f) / oldPpm)
            val next = (timelineZoom * factor).coerceIn(0.35f, 5f)
            if (abs(next - timelineZoom) >= 0.015f) {
                timelineZoom = next
                drawTimeline()
                val newPpm = timelinePixelsPerMs()
                timelineScroll.post {
                    val target = (dp(108) + focusTime * newPpm - focusX).roundToInt().coerceAtLeast(0)
                    timelineScroll.scrollTo(target, 0)
                    timelineRulerView.invalidate()
                }
            }
        }
        timelineScroll.setOnScrollChangeListener { _, _, _, _, _ -> timelineRulerView.invalidate() }

        outer.addView(shell, LinearLayout.LayoutParams(0, -1, 1f))
        return outer
    }

    private fun buildToolRail(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; setPadding(0, dp(66), 0, 0); setBackgroundColor(Color.rgb(29,29,33))
            listOf(
                "V" to "Outil Sélection",
                "A" to "Sélection de piste",
                "B" to "Modification propagation",
                "C" to "Lame",
                "Y" to "Déplacement dessous",
                "P" to "Plume",
                "H" to "Main",
                "T" to "Texte"
            ).forEach { (glyph, name) ->
                addView(smallIcon(glyph) { if (glyph == "C") splitSelectedClip() else if (glyph == "T") addTextLayer() else toast(name) }, LinearLayout.LayoutParams(dp(34), dp(31)))
            }
        }
    }

    private fun buildEffectsPanel(): View {
        val shell = panelShell()
        shell.addView(panelTabs("Propriétés", "Contrôles d'effets", "Effets"))
        shell.addView(thinDivider(), LinearLayout.LayoutParams(-1, dp(1)))
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6),dp(4),dp(6),dp(4)); setBackgroundColor(Color.rgb(29,29,33))
            addView(TextView(this@MainActivity).apply {
                text = "⌕  Rechercher dans les effets"; setTextColor(Color.rgb(142,142,148)); textSize = 9f; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(7),0,dp(7),0); background = strokeBox(Color.rgb(38,38,43), Color.rgb(70,70,76), 3f)
            }, LinearLayout.LayoutParams(0, dp(27), 1f))
            addView(smallIcon("≡") { toast("Menu du panneau") })
        }
        shell.addView(mini, LinearLayout.LayoutParams(-1, dp(36)))
        val scroll = ScrollView(this)
        effectList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(5), dp(8), dp(8)) }
        scroll.addView(effectList)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return shell
    }

    private fun panelShell() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(panel3) }

    private fun panelTabs(vararg names: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2),0,dp(2),0); setBackgroundColor(Color.rgb(33,33,37))
            names.forEachIndexed { i, n ->
                val tab = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    addView(TextView(this@MainActivity).apply {
                        text = n; setTextColor(if (i == 0) Color.rgb(239,239,242) else Color.rgb(159,159,166)); textSize = 9f; gravity = Gravity.CENTER
                        setPadding(dp(8),0,dp(8),0)
                    }, LinearLayout.LayoutParams(-2, 0, 1f))
                    addView(View(this@MainActivity).apply { setBackgroundColor(if (i == 0) Color.rgb(104,124,255) else Color.TRANSPARENT) }, LinearLayout.LayoutParams(-1, dp(2)))
                }
                addView(tab, LinearLayout.LayoutParams(-2, dp(33)))
            }
            addView(Space(this@MainActivity), LinearLayout.LayoutParams(0,1,1f))
            addView(smallIcon("≡") { toast("Menu du panneau") }, LinearLayout.LayoutParams(dp(27), dp(30)))
        }
    }

    private fun workspaceTab(name: String, active: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        addView(TextView(this@MainActivity).apply {
            text = name; setTextColor(if (active) Color.WHITE else Color.rgb(157,157,163)); textSize = 9f; gravity = Gravity.CENTER; setPadding(dp(8),0,dp(8),0)
        }, LinearLayout.LayoutParams(-2, 0, 1f))
        addView(View(this@MainActivity).apply { setBackgroundColor(if (active) Color.rgb(109,126,255) else Color.TRANSPARENT) }, LinearLayout.LayoutParams(-1, dp(2)))
    }

    private fun menuText(name: String) = TextView(this).apply {
        text = name; setTextColor(Color.rgb(211,211,216)); textSize = 9f; gravity = Gravity.CENTER; setPadding(dp(7),0,dp(7),0)
        setOnClickListener { toast(name) }
    }

    private fun thinDivider() = View(this).apply { setBackgroundColor(divider) }
    private fun separatorVertical() = View(this).apply { setBackgroundColor(Color.rgb(61,61,67)) }

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun strokeBox(fill: Int, stroke: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun smallIcon(caption: String, action: () -> Unit) = TextView(this).apply {
        text = caption; setTextColor(Color.rgb(211,211,216)); textSize = 11f; gravity = Gravity.CENTER
        setPadding(dp(5),0,dp(5),0); setOnClickListener { action() }
    }

    private fun labelSmall(s: String) = TextView(this).apply {
        text = s; setTextColor(Color.rgb(174,174,180)); textSize = 8f; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6),0,dp(6),0)
    }

    private fun primaryButton(caption: String, action: () -> Unit) = TextView(this).apply {
        text = caption; setTextColor(Color.WHITE); textSize = 9f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
        background = rounded(Color.rgb(82,99,215), 4f); setPadding(dp(11),0,dp(11),0); setOnClickListener { action() }
    }

    private fun refreshEffectsPanel() {
        if (!::effectList.isInitialized) return
        effectList.removeAllViews()
        val clip = project.selectedClip()
        if (clip == null) {
            effectList.addView(label("Sélectionne un clip pour modifier ses effets.")); return
        }
        effectList.addView(label("Clip : ${clip.name}"))
        opacitySeek = slider("Opacité", (clip.opacity * 100).roundToInt(), 0, 100) { v -> clip.opacity = v / 100f; preview.alpha = clip.opacity }
        scaleSeek = slider("Échelle", ((clip.scale - .25f) / 1.75f * 100).roundToInt(), 0, 100) { v ->
            clip.scale = .25f + (v / 100f) * 1.75f; preview.scaleX = clip.scale; preview.scaleY = clip.scale
        }
        rotationSeek = slider("Rotation", (((clip.rotation + 180f) / 360f) * 100).roundToInt(), 0, 100) { v -> clip.rotation = (v / 100f) * 360f - 180f; preview.rotation = clip.rotation }
        volumeSeek = slider("Volume", (clip.volume * 100).roundToInt(), 0, 100) { v -> clip.volume = v / 100f; mediaPlayer?.setVolume(clip.volume, clip.volume) }
        effectList.addView(opacitySeek); effectList.addView(scaleSeek); effectList.addView(rotationSeek); effectList.addView(volumeSeek)
        effectList.addView(button("Réinitialiser transformation") {
            clip.opacity = 1f; clip.scale = 1f; clip.rotation = 0f; clip.volume = 1f
            applyClipPreviewProperties(clip); refreshEffectsPanel()
        })
        effectList.addView(title("PISTE"))
        val trackButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (track in 0..2) trackButtons.addView(button("V${track + 1}") {
            clip.track = track; drawTimeline(); refreshProjectPanel()
        })
        effectList.addView(trackButtons)
        effectList.addView(button("Dupliquer le clip") {
            val clone = clip.copy(id = System.nanoTime(), timelineStartMs = clip.timelineStartMs + clip.durationMs, appliedPresets = clip.appliedPresets.toMutableList())
            project.clips += clone; project.selectedClipId = clone.id
            refreshProjectPanel(); refreshEffectsPanel(); drawTimeline()
        })
        effectList.addView(button("Supprimer le clip") {
            project.clips.removeAll { it.id == clip.id }
            project.selectedClipId = project.clips.lastOrNull()?.id
            refreshProjectPanel(); refreshEffectsPanel(); drawTimeline()
        })
        effectList.addView(title("PRESETS APPLIQUÉS"))
        if (clip.appliedPresets.isEmpty()) effectList.addView(label("Aucun"))
        clip.appliedPresets.forEach { p ->
            effectList.addView(TextView(this).apply {
                setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(panel2)
                text = "${p.name}\n${p.effects.size} effet(s) importé(s)"
            })
        }
        loadedPreset?.let { p -> effectList.addView(button("Appliquer preset chargé : ${p.name.take(18)}") { applyLoadedPreset() }) }
    }

    private fun slider(label: String, progressValue: Int, min: Int, max: Int, onChange: (Int) -> Unit): SeekBar {
        effectList.addView(label(label))
        return SeekBar(this).apply {
            this.max = max; progress = progressValue.coerceIn(min, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) onChange(progress) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
    }

    private fun openMedia() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*", "image/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, REQ_MEDIA)
    }

    private fun openPreset() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, REQ_PRESET)
    }

    @Deprecated("Activity result API kept intentionally for minSdk compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        when (requestCode) {
            REQ_MEDIA -> loadMedia(uri, addToProject = true)
            REQ_PRESET -> importPreset(uri)
        }
    }

    private fun loadMedia(uri: Uri, addToProject: Boolean) {
        currentMedia = uri; inMs = 0
        if (addToProject) {
            val start = project.clips.filter { it.track == 0 }.maxOfOrNull { it.timelineStartMs + it.durationMs } ?: 0L
            val clip = ClipModel(uri = uri, name = displayName(uri), timelineStartMs = start, track = 0)
            project.clips += clip; project.selectedClipId = clip.id
            refreshProjectPanel(); refreshEffectsPanel()
        }
        preview.setVideoURI(uri); preview.requestFocus(); status.text = "Chargement : ${displayName(uri)}"
    }

    private fun selectClipForTouch(clip: ClipModel) {
        project.selectedClipId = clip.id
        inMs = clip.sourceInMs
        outMs = clip.sourceOutMs
        refreshProjectPanel()
        refreshEffectsPanel()
        refreshTrimLabels()
    }

    private fun selectClip(clip: ClipModel) {
        selectClipForTouch(clip)
        currentMedia = clip.uri
        preview.setVideoURI(clip.uri)
        preview.requestFocus()
        drawTimeline()
    }

    private fun ensureClipPreview(clip: ClipModel) {
        if (currentMedia != clip.uri) {
            currentMedia = clip.uri
            preview.setVideoURI(clip.uri)
            preview.requestFocus()
        }
    }

    private fun importPreset(uri: Uri) {
        status.text = "Analyse du preset Adobe…"
        thread {
            try {
                val preset = PresetParser.parse(contentResolver, uri); loadedPreset = preset
                runOnUiThread {
                    refreshEffectsPanel(); showPresetReport(preset); status.text = "Preset analysé : ${preset.name}"
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Erreur preset"; toast("Preset illisible : ${e.message}") } }
        }
    }

    private fun showPresetReport(preset: Preset) {
        val native = preset.effects.count { it.support == PresetSupport.NATIVE }
        val approx = preset.effects.count { it.support == PresetSupport.APPROXIMATE }
        val imported = preset.effects.count { it.support == PresetSupport.IMPORT_ONLY }
        val body = buildString {
            append("${preset.sourceType}\n\n")
            append("${preset.effects.size} effet(s) trouvé(s) — natifs: $native, approximés: $approx, import seulement: $imported\n\n")
            preset.effects.take(20).forEach { e ->
                append("• ${e.displayName}")
                if (e.matchName.isNotBlank() && e.matchName != e.displayName) append(" [${e.matchName}]")
                append(" — ${e.support}\n")
                e.parameters.take(6).forEach { p -> append("    ${p.name}: ${p.value ?: "—"}${p.units?.let { " $it" } ?: ""}${if (p.timeVarying) "  ◆ keyframes" else ""}\n") }
            }
            if (preset.warnings.isNotEmpty()) append("\n⚠ ${preset.warnings.joinToString("\n⚠ ")}")
        }
        AlertDialog.Builder(this).setTitle(preset.name).setMessage(body).setPositiveButton("Appliquer") { _, _ -> applyLoadedPreset() }.setNegativeButton("Fermer", null).show()
    }

    private fun applyLoadedPreset() {
        val preset = loadedPreset ?: return toast("Importe un preset")
        val clip = project.selectedClip() ?: return toast("Sélectionne un clip")
        clip.appliedPresets += preset
        applyKnownPresetValues(clip, preset)
        refreshEffectsPanel(); drawTimeline(); status.text = "Preset appliqué : ${preset.name}"
    }

    private fun applyKnownPresetValues(clip: ClipModel, preset: Preset) {
        preset.effects.forEach { e ->
            val key = "${e.displayName} ${e.matchName}".lowercase()
            fun value(vararg names: String): Float? = e.parameters.firstOrNull { p -> names.any { p.name.contains(it, true) } }?.value?.toFloatOrNull()
            if ("opacity" in key || "opacité" in key) value("Opacity", "Opacité")?.let { raw -> clip.opacity = normalizePercent(raw) }
            if ("motion" in key || "transform" in key || "mouvement" in key) {
                value("Scale", "Échelle")?.let { raw -> clip.scale = if (raw > 3f) raw / 100f else raw }
                value("Rotation")?.let { clip.rotation = it }
            }
            if ("volume" in key || "gain" in key) value("Level", "Volume", "Gain")?.let { raw -> clip.volume = raw.coerceIn(0f, 1f) }
        }
        applyClipPreviewProperties(clip)
    }

    private fun normalizePercent(v: Float): Float = when { v > 1.5f -> (v / 100f).coerceIn(0f, 1f); else -> v.coerceIn(0f, 1f) }

    private fun splitSelectedClip() {
        val clip = project.selectedClip() ?: return toast("Sélectionne un clip")
        val oldOut = clip.sourceOutMs.takeIf { it > 0 } ?: currentDurationMs
        if (oldOut <= clip.sourceInMs + 2) return toast("Clip trop court")
        val cut = preview.currentPosition.toLong().coerceIn(clip.sourceInMs + 1, oldOut - 1)
        clip.sourceOutMs = cut
        val second = clip.copy(
            id = System.nanoTime(), sourceInMs = cut, sourceOutMs = oldOut,
            timelineStartMs = clip.timelineStartMs + clip.durationMs,
            appliedPresets = clip.appliedPresets.toMutableList()
        )
        project.clips += second; project.selectedClipId = second.id
        refreshProjectPanel(); refreshEffectsPanel(); drawTimeline(); status.text = "Clip découpé à ${formatMs(cut)}"
    }

    private fun addTextLayer() {
        val input = EditText(this).apply { hint = "Ton texte"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        AlertDialog.Builder(this).setTitle("Ajouter un texte").setView(input)
            .setPositiveButton("Ajouter") { _, _ ->
                val layer = TextLayerModel(text = input.text.toString().ifBlank { "Texte" }, startMs = preview.currentPosition.toLong())
                project.textLayers += layer; addPreviewText(layer); drawTimeline(); status.text = "Texte ajouté"
            }.setNegativeButton("Annuler", null).show()
    }

    private fun addPreviewText(layer: TextLayerModel) {
        val tv = TextView(this).apply {
            text = layer.text; setTextColor(Color.WHITE); textSize = 28f; setTypeface(typeface, Typeface.BOLD)
            setShadowLayer(4f, 2f, 2f, Color.BLACK); gravity = Gravity.CENTER; setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        previewFrame.addView(tv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)); textViews[layer.id] = tv
    }

    private fun saveProject() {
        try { val file = ProjectStore.save(this, project); status.text = "Projet sauvegardé : ${file.name}"; toast("Projet sauvegardé") }
        catch (e: Exception) { toast("Erreur sauvegarde : ${e.message}") }
    }

    private fun exportSelectedTrim() {
        val clip = project.selectedClip() ?: return toast("Sélectionne une vidéo")
        val end = clip.sourceOutMs.takeIf { it > clip.sourceInMs } ?: currentDurationMs
        val output = File(getExternalFilesDir(null), "export_${System.currentTimeMillis()}.mp4")
        status.text = "Export sans réencodage…"
        thread {
            try {
                TrimExporter.export(contentResolver, clip.uri, output, clip.sourceInMs, end)
                runOnUiThread { status.text = "Export terminé : ${output.name}"; AlertDialog.Builder(this).setTitle("Export terminé").setMessage(output.absolutePath + "\n\nNote : l'export V0.5 découpe le média sans perte. Les transformations/presets sont visibles dans le projet mais le rendu GPU final viendra dans le moteur de rendu suivant.").setPositiveButton("OK", null).show() }
            } catch (e: Exception) { runOnUiThread { status.text = "Erreur export"; toast(e.message ?: "Erreur") } }
        }
    }

    private fun refreshProjectPanel() {
        if (!::projectList.isInitialized) return
        projectList.removeAllViews()
        if (project.clips.isEmpty()) projectList.addView(label("Aucun média.\nAppuie sur + Média."))
        project.clips.forEachIndexed { index, clip ->
            projectList.addView(TextView(this).apply {
                setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(8), dp(10), dp(8), dp(10))
                setBackgroundColor(if (clip.id == project.selectedClipId) accent else panel2)
                text = "V${clip.track + 1}  ${index + 1}. ${clip.name}\n${formatMs(clip.sourceInMs)} → ${formatMs(clip.sourceOutMs)}"
                setOnClickListener { selectClip(clip) }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(5)) })
        }
    }

    private fun drawTimeline() {
        if (!::timeline.isInitialized) return
        timeline.removeAllViews()
        val contentWidth = timelineContentWidth()
        timeline.minimumWidth = contentWidth
        timelineFrame.minimumWidth = contentWidth

        for (track in 2 downTo 0) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.rgb(24,24,28))
                clipChildren = false
                clipToPadding = false
                minimumWidth = contentWidth
            }
            row.addView(trackHeader("V${track + 1}", audio = false), LinearLayout.LayoutParams(dp(108), dp(52)))
            val lane = FrameLayout(this).apply {
                setBackgroundColor(if (track % 2 == 0) Color.rgb(27,27,31) else Color.rgb(25,25,29))
                minimumWidth = contentWidth - dp(108)
                clipChildren = false
                clipToPadding = false
            }
            val clips = project.clips.filter { it.track == track }.sortedBy { it.timelineStartMs }
            clips.forEach { clip ->
                val clipView = TimelineClipView(
                    context = this,
                    title = "${clip.name.take(24)}${if (clip.appliedPresets.isNotEmpty()) "   ◆" else ""}",
                    selected = clip.id == project.selectedClipId,
                    onTouchSelect = { selectClipForTouch(clip) },
                    onTap = { selectClip(clip) },
                    onMoveCommit = { dx, dy -> commitClipMove(clip, dx, dy) },
                    onTrimLeftCommit = { dx -> commitClipTrimLeft(clip, dx) },
                    onTrimRightCommit = { dx -> commitClipTrimRight(clip, dx) },
                    onDragMove = { rawX -> autoScrollTimeline(rawX) },
                    scrollXProvider = { if (::timelineScroll.isInitialized) timelineScroll.scrollX else 0 }
                )
                lane.addView(clipView, FrameLayout.LayoutParams(clipDisplayWidth(clip.durationMs.coerceAtLeast(120L)), dp(46)).apply {
                    leftMargin = timeWidth(clip.timelineStartMs)
                    topMargin = dp(2)
                })
            }
            row.addView(lane, LinearLayout.LayoutParams(contentWidth - dp(108), dp(52)))
            timeline.addView(row, LinearLayout.LayoutParams(contentWidth, dp(52)))
            timeline.addView(View(this).apply { setBackgroundColor(Color.rgb(42,42,47)) }, LinearLayout.LayoutParams(contentWidth, dp(1)))
        }

        for (track in 0..2) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.rgb(24,24,28)); minimumWidth = contentWidth
            }
            row.addView(trackHeader("A${track + 1}", audio = true), LinearLayout.LayoutParams(dp(108), dp(46)))
            val lane = FrameLayout(this).apply {
                setBackgroundColor(Color.rgb(25,25,29)); minimumWidth = contentWidth - dp(108)
            }
            val sourceClips = project.clips.filter { it.track == track }.sortedBy { it.timelineStartMs }
            sourceClips.forEach { clip ->
                lane.addView(TextView(this).apply {
                    text = " ▂▅▃▆▂▇▃▅▂▆  ${clip.name.take(14)}  ▃▇▂▆▅▂▇▃ "
                    setTextColor(Color.rgb(205,235,222)); textSize = 8f; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4),0,dp(4),0)
                    background = strokeBox(if (clip.id == project.selectedClipId) Color.rgb(58,130,102) else audioGreen, Color.rgb(70,139,111), 2f)
                    setOnClickListener { selectClip(clip) }
                }, FrameLayout.LayoutParams(clipDisplayWidth(clip.durationMs.coerceAtLeast(120L)), dp(40)).apply {
                    leftMargin = timeWidth(clip.timelineStartMs)
                    topMargin = dp(2)
                })
            }
            row.addView(lane, LinearLayout.LayoutParams(contentWidth - dp(108), dp(46)))
            timeline.addView(row, LinearLayout.LayoutParams(contentWidth, dp(46)))
            timeline.addView(View(this).apply { setBackgroundColor(Color.rgb(42,42,47)) }, LinearLayout.LayoutParams(contentWidth, dp(1)))
        }

        if (project.textLayers.isNotEmpty()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; minimumWidth = contentWidth }
            row.addView(trackHeader("GFX", audio = false), LinearLayout.LayoutParams(dp(108), dp(44)))
            val lane = FrameLayout(this).apply { minimumWidth = contentWidth - dp(108) }
            project.textLayers.sortedBy { it.startMs }.forEach { layer ->
                lane.addView(TextView(this).apply {
                    text = " T  ${layer.text.take(18)}"; setTextColor(Color.WHITE); textSize = 9f; gravity = Gravity.CENTER_VERTICAL
                    background = strokeBox(Color.rgb(111,65,143), Color.rgb(155,104,190), 2f)
                }, FrameLayout.LayoutParams(clipDisplayWidth(layer.durationMs), dp(39)).apply {
                    leftMargin = timeWidth(layer.startMs)
                    topMargin = dp(2)
                })
            }
            row.addView(lane, LinearLayout.LayoutParams(contentWidth - dp(108), dp(44)))
            timeline.addView(row, LinearLayout.LayoutParams(contentWidth, dp(44)))
        }

        updatePlayheadVisual()
        timelineRulerView.invalidate()
        findViewByTag<TextView>(window.decorView, "zoomLabel")?.text = "${(timelineZoom * 100).roundToInt()}%"
    }

    private fun autoScrollTimeline(rawX: Float) {
        if (!::timelineScroll.isInitialized) return
        val loc = IntArray(2)
        timelineScroll.getLocationOnScreen(loc)
        val left = loc[0].toFloat()
        val right = left + timelineScroll.width
        val edge = dp(48).toFloat()
        when {
            rawX < left + edge -> timelineScroll.scrollBy(-dp(18), 0)
            rawX > right - edge -> timelineScroll.scrollBy(dp(18), 0)
        }
        timelineRulerView.invalidate()
    }

    private fun commitClipMove(clip: ClipModel, dxPx: Float, dyPx: Float) {
        val deltaMs = (dxPx / timelinePixelsPerMs()).roundToLong()
        val targetStart = snapTimelineTime((clip.timelineStartMs + deltaMs).coerceAtLeast(0L), clip.id)
        val trackDelta = (-dyPx / dp(53).toFloat()).roundToInt()
        clip.timelineStartMs = targetStart
        clip.track = (clip.track + trackDelta).coerceIn(0, 2)
        project.selectedClipId = clip.id
        ensureClipPreview(clip)
        setPlayheadTimelineTime(clip.timelineStartMs, seekPreview = false)
        refreshProjectPanel(); refreshEffectsPanel(); drawTimeline()
        status.text = "Déplacé : ${formatMs(clip.timelineStartMs)} • V${clip.track + 1}"
    }

    private fun commitClipTrimLeft(clip: ClipModel, dxPx: Float) {
        if (clip.durationMs <= 0) return
        val rawDelta = (dxPx / timelinePixelsPerMs()).roundToLong()
        val snappedStart = snapTimelineTime((clip.timelineStartMs + rawDelta).coerceAtLeast(0L), clip.id)
        var delta = snappedStart - clip.timelineStartMs
        val minDelta = maxOf(-clip.sourceInMs, -clip.timelineStartMs)
        val maxDelta = (clip.durationMs - 120L).coerceAtLeast(0L)
        delta = delta.coerceIn(minDelta, maxDelta)
        clip.sourceInMs += delta
        clip.timelineStartMs += delta
        ensureClipPreview(clip)
        syncSelectedTrim(clip)
        drawTimeline()
        status.text = "Trim entrée : ${formatMs(clip.sourceInMs)}"
    }

    private fun commitClipTrimRight(clip: ClipModel, dxPx: Float) {
        if (clip.durationMs <= 0) return
        val oldEnd = clip.timelineStartMs + clip.durationMs
        val rawDelta = (dxPx / timelinePixelsPerMs()).roundToLong()
        val snappedEnd = snapTimelineTime((oldEnd + rawDelta).coerceAtLeast(clip.timelineStartMs + 120L), clip.id)
        var delta = snappedEnd - oldEnd
        val minDelta = -(clip.durationMs - 120L).coerceAtLeast(0L)
        val maxDelta = if (clip.sourceDurationMs > 0) (clip.sourceDurationMs - clip.sourceOutMs).coerceAtLeast(0L) else 0L
        delta = delta.coerceIn(minDelta, maxDelta)
        clip.sourceOutMs += delta
        ensureClipPreview(clip)
        syncSelectedTrim(clip)
        drawTimeline()
        status.text = "Trim sortie : ${formatMs(clip.sourceOutMs)}"
    }

    private fun syncSelectedTrim(clip: ClipModel) {
        if (project.selectedClipId == clip.id) {
            inMs = clip.sourceInMs
            outMs = clip.sourceOutMs
            refreshTrimLabels()
            preview.seekTo(clip.sourceInMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        }
    }

    private fun snapTimelineTime(rawMs: Long, excludeClipId: Long? = null): Long {
        val safe = rawMs.coerceAtLeast(0L)
        if (!snappingEnabled) return safe
        val thresholdMs = (dp(12) / timelinePixelsPerMs()).roundToLong().coerceIn(40L, 500L)
        val edges = mutableListOf(0L)
        project.clips.filter { it.id != excludeClipId }.forEach { c ->
            edges += c.timelineStartMs
            edges += c.timelineStartMs + c.durationMs
        }
        project.textLayers.forEach { t -> edges += t.startMs; edges += t.startMs + t.durationMs }
        val nearest = edges.minByOrNull { abs(it - safe) }
        if (nearest != null && abs(nearest - safe) <= thresholdMs) return nearest
        val frame = 40L // 25 fps
        return ((safe.toDouble() / frame).roundToLong() * frame).coerceAtLeast(0L)
    }

    private fun setPlayheadTimelineTime(ms: Long, seekPreview: Boolean) {
        playheadTimeMs = ms.coerceIn(0L, project.durationMs().coerceAtLeast(30_000L))
        updatePlayheadVisual()
        if (::timelineRulerView.isInitialized) timelineRulerView.invalidate()
        findViewByTag<TextView>(window.decorView, "timelineTimecode")?.text = formatTimecode(playheadTimeMs)
        if (seekPreview) {
            val clip = project.selectedClip()
            if (clip != null && playheadTimeMs in clip.timelineStartMs..(clip.timelineStartMs + clip.durationMs)) {
                val source = clip.sourceInMs + (playheadTimeMs - clip.timelineStartMs)
                preview.seekTo(source.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt())
            }
        }
    }

    private fun updatePlayheadVisual() {
        if (!::playheadView.isInitialized) return
        val lp = (playheadView.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(dp(2), -1)
        lp.width = dp(2)
        lp.height = FrameLayout.LayoutParams.MATCH_PARENT
        lp.leftMargin = dp(108) + (playheadTimeMs * timelinePixelsPerMs()).roundToInt()
        playheadView.layoutParams = lp
        playheadView.bringToFront()
    }

    private fun timelinePixelsPerMs(): Float = (dp(105).toFloat() * timelineZoom) / 1000f

    private fun timelineContentWidth(): Int {
        val duration = project.durationMs().coerceAtLeast(30_000L) + 10_000L
        return (dp(108) + duration * timelinePixelsPerMs()).roundToInt().coerceAtLeast(dp(1600))
    }

    private fun rulerStepMs(): Long {
        val pps = timelinePixelsPerMs() * 1000f
        return when {
            pps < dp(45) -> 10_000L
            pps < dp(80) -> 5_000L
            pps < dp(150) -> 2_000L
            pps < dp(320) -> 1_000L
            else -> 500L
        }
    }

    private fun timeWidth(ms: Long): Int = (ms.coerceAtLeast(0L) * timelinePixelsPerMs()).roundToInt().coerceAtLeast(0)
    private fun clipDisplayWidth(ms: Long): Int = timeWidth(ms).coerceAtLeast(dp(48))

    private fun <T : View> findViewByTag(root: View?, tag: String): T? {
        if (root == null) return null
        if (root.tag == tag) {
            @Suppress("UNCHECKED_CAST")
            return root as? T
        }
        if (root is android.view.ViewGroup) {
            for (i in 0 until root.childCount) {
                val found = findViewByTag<T>(root.getChildAt(i), tag)
                if (found != null) return found
            }
        }
        return null
    }

    private fun trackHeader(name: String, audio: Boolean): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(3),0,dp(3),0); setBackgroundColor(Color.rgb(31,31,35))
            addView(TextView(this@MainActivity).apply {
                text = name; setTextColor(Color.rgb(198,198,204)); textSize = 9f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
            }, LinearLayout.LayoutParams(dp(26), -1))
            addView(TextView(this@MainActivity).apply { text = "🔒"; setTextColor(Color.rgb(130,130,136)); textSize = 8f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(22), -1))
            addView(TextView(this@MainActivity).apply { text = if (audio) "M" else "◉"; setTextColor(Color.rgb(145,145,152)); textSize = 8f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(22), -1))
            addView(TextView(this@MainActivity).apply { text = if (audio) "S" else "▣"; setTextColor(Color.rgb(145,145,152)); textSize = 8f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(22), -1))
        }
    }

    private fun applyClipPreviewProperties(clip: ClipModel) {
        preview.alpha = clip.opacity; preview.scaleX = clip.scale; preview.scaleY = clip.scale; preview.rotation = clip.rotation
        mediaPlayer?.setVolume(clip.volume, clip.volume)
    }

    private fun refreshTrimLabels() {
        if (::inText.isInitialized) inText.text = "IN ${formatMs(inMs)}"
        if (::outText.isInitialized) outText.text = "OUT ${formatMs(outMs)}"
    }

    private fun seekRelative(delta: Int) {
        if (currentMedia == null) return
        val target = (preview.currentPosition + delta).coerceIn(0, preview.duration.coerceAtLeast(0)); preview.seekTo(target)
    }

    private fun button(caption: String, action: () -> Unit) = TextView(this).apply {
        text = caption; setTextColor(Color.rgb(221,221,226)); textSize = 9f; gravity = Gravity.CENTER
        background = strokeBox(Color.rgb(45,45,50), Color.rgb(67,67,74), 3f); setPadding(dp(9), 0, dp(9), 0); setOnClickListener { action() }
    }
    private fun title(s: String) = TextView(this).apply { text = s; setTextColor(Color.LTGRAY); textSize = 12f; setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(4), 0, dp(8)) }
    private fun label(s: String) = TextView(this).apply { text = s; setTextColor(text); textSize = 12f; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)) }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return uri.lastPathSegment ?: "media"
    }
    private fun formatMs(ms: Long): String { val m = ms.coerceAtLeast(0); return "%02d:%02d.%03d".format(m / 60000, (m / 1000) % 60, m % 1000) }
    private fun formatTimecode(ms: Long): String {
        val m = ms.coerceAtLeast(0); val totalSeconds = m / 1000; val frames = ((m % 1000) * 25 / 1000).toInt()
        return "%02d:%02d:%02d:%02d".format(totalSeconds / 3600, (totalSeconds / 60) % 60, totalSeconds % 60, frames)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object { const val REQ_MEDIA = 10; const val REQ_PRESET = 11 }
}
