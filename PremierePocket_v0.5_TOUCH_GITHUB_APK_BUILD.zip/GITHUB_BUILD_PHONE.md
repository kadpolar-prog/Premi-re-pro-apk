# Generer l'APK depuis un telephone avec GitHub

## Une seule fois
1. Cree un nouveau depot GitHub vide.
2. Mets **le contenu de ce dossier** a la racine du depot (pas le ZIP lui-meme).
3. Verifie que `.github/workflows/build-apk.yml` est bien present.

## Compiler
1. Ouvre le depot sur github.com.
2. Va dans **Actions**.
3. Ouvre **Build Premiere Pocket APK**.
4. Appuie sur **Run workflow** puis encore **Run workflow**.
5. Quand le build est vert, ouvre-le.
6. En bas de la page, dans **Artifacts**, telecharge **PremierePocket-APK**.
7. Decompresse l'archive GitHub obtenue et installe `PremierePocket-v0.5-TOUCH.apk`.

## Si Android bloque l'installation
Autorise temporairement l'installation d'applications inconnues pour ton navigateur ou ton gestionnaire de fichiers, puis ouvre l'APK.

Le workflow compile une version Debug signee automatiquement par Android, donc elle est installable pour tester l'application.
