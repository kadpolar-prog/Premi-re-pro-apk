# Premiere Pocket v0.5 — Touch Timeline

Prototype Android/Kotlin d'un éditeur vidéo mobile inspiré du workflow et de la disposition de Premiere Pro 2026, avec une timeline pensée pour le tactile et **zéro IA**.

## Nouveau dans v0.5 : tactile propre
- Tap sur un clip : sélection sans déplacement accidentel.
- Seuil tactile avant activation d'un drag.
- Glisser le centre du clip : déplacement temporel.
- Glisser verticalement : passage V1 / V2 / V3.
- Poignée gauche : trim du point d'entrée.
- Poignée droite : trim du point de sortie.
- Pinch à deux doigts : zoom temporel 35 % → 500 %.
- Le pinch fonctionne même lorsqu'il démarre directement sur un clip.
- Auto-scroll horizontal lorsqu'un clip est tiré près du bord de l'écran.
- Accrochage aux bords des autres clips / textes et aux images à 25 i/s.
- Bouton d'accrochage activable/désactivable.
- Règle temporelle dynamique selon le niveau de zoom.
- Playhead bleu tactile : glisser sur la règle pour scrubber.
- Le playhead suit la vraie échelle temporelle de la timeline.
- Retour haptique au début et à la fin d'une modification.

## Interface
- Projet / Source / Programme / Propriétés / Timeline.
- V1/V2/V3 + A1/A2/A3 + GFX.
- Barre d'outils verticale.
- Waveforms audio visuelles.
- Timecode et commandes de transport.
- Interface paysage, sombre et compacte.

## Fonctions conservées
- Import vidéo/audio/image via Storage Access Framework.
- Prévisualisation vidéo.
- Points IN/OUT et découpe au curseur.
- Texte superposé.
- Opacité, échelle, rotation et volume.
- Import `.prfpset` : résolution `ObjectRef`, `FilterPreset`, composants, paramètres, valeurs, unités et métadonnées de keyframes.
- Rapport de compatibilité NATIVE / APPROXIMATE / IMPORT_ONLY.
- Sauvegarde locale du projet en JSON.
- Export MP4 sans réencodage du clip sélectionné entre IN/OUT.
- Aucune IA, aucune API IA et aucun modèle cloud/local.

## Presets Premiere
Un `.prfpset` peut référencer des effets internes Adobe ou des plugins tiers absents d'Android. Premiere Pocket conserve et analyse les données disponibles et applique les équivalents implémentés dans son propre moteur. Il n'embarque aucun code propriétaire Adobe.

## Compilation
Ouvrir le projet dans Android Studio puis `Build > Build APK(s)`. Le projet cible Android 35 et minSdk 26.
